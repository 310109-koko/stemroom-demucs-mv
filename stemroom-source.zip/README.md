# Stemroom — Demucs MV Studio

繁體中文、純前端的音樂分軌與伴奏 MV 工具。推論在瀏覽器本機執行，使用者選取的媒體不會送到網站伺服器。

![Stemroom 介面](docs/screenshots/stemroom-home.jpg)

## 功能

- 匯入常見音訊格式與 MP4 / WebM / MOV；影片音軌可直接解碼時會直接載入，否則由瀏覽器播放擷取。
- 使用 HTDemucs / ONNX Runtime Web 分離人聲、鼓組、貝斯與其他樂器。
- 個別音軌音量、獨奏、靜音、試聽與 WAV 下載。
- 混音播放與 WAV 匯出；以半音為單位升降 Key（播放速度也會一起改變）。
- 以原影片配上混音，即時錄製並匯出 WEBM 伴奏 MV。
- Vite 靜態建置與 GitHub Pages Actions 部署流程。

## 開發

```sh
npm ci
npm run dev
```

## 部署到 GitHub Pages

將 `main` 分支推送到 GitHub 後，`Deploy Stemroom to GitHub Pages` workflow 會自動建置與發佈。第一次需在 GitHub 專案的 **Settings → Pages** 選擇 **GitHub Actions** 作為來源。

首次分離需下載約 172 MB 的 HTDemucs ONNX 模型；模型由 Hugging Face 提供並由瀏覽器快取。GitHub Pages 只提供網頁靜態檔案，不接收使用者音樂。

## 技術與授權

本專案的分離核心移植自 [`timcsy/demucs-web`](https://github.com/timcsy/demucs-web)，採用 MIT License；原作者授權文字保留於 [`lib/demucs-web/LICENSE`](lib/demucs-web/LICENSE)。網站使用 ONNX Runtime Web、Vite 與 Web Audio API。Demucs 模型由 Hugging Face 專案提供。
