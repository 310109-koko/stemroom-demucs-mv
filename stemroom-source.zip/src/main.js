import * as ort from 'onnxruntime-web';
import { DemucsProcessor, CONSTANTS } from 'demucs-web';
import './style.css';

const $ = (id) => document.getElementById(id);
const names = { vocals: '人聲', drums: '鼓組', bass: '貝斯', other: '其他樂器' };
const colors = { vocals: 'coral', drums: 'lime', bass: 'blue', other: 'violet' };
const { SAMPLE_RATE, DEFAULT_MODEL_URL } = CONSTANTS;
let audioContext;
let processor;
let sourceFile;
let sourceVideoUrl;
let audioBuffer;
let stems = {};
let controls = {};
let keyShift = 0;
let playingSources = [];
let playStartedAt = 0;
let playOffset = 0;
let isPlaying = false;
let videoSourceNode;
let videoGain;
let capturePromise;
let recordStop;

const input = $('fileInput');
const video = $('videoPreview');
const notice = $('notice');
const setNotice = (text, type = '') => { notice.textContent = text; notice.className = `notice ${type}`; };
const timeText = (seconds) => `${String(Math.floor(Math.max(0, seconds) / 60)).padStart(2, '0')}:${String(Math.floor(Math.max(0, seconds) % 60)).padStart(2, '0')}`;
const duration = () => audioBuffer?.duration || 0;
const objectUrl = (blob) => URL.createObjectURL(blob);

function initAudio() { if (!audioContext) audioContext = new AudioContext({ sampleRate: SAMPLE_RATE }); return audioContext; }

async function loadVideoAudio(file) {
  const ctx = initAudio();
  video.src = sourceVideoUrl || objectUrl(file);
  video.hidden = false;
  $('videoFeatureText').textContent = '已載入 MV，可在下方預覽畫面';
  $('downloadMv').disabled = false;
  try {
    return await ctx.decodeAudioData(await file.arrayBuffer());
  } catch {
    setNotice('瀏覽器無法直接解碼此影片，將以即時播放擷取音訊；請保持此分頁開啟。', 'warn');
    return await captureVideoAudio(ctx);
  }
}

function captureVideoAudio(ctx) {
  if (capturePromise) return capturePromise;
  capturePromise = new Promise(async (resolve, reject) => {
    try {
      if (!window.MediaRecorder || !video.captureStream) throw new Error('此瀏覽器不支援影片音訊擷取，請改用 MP3/WAV/M4A 音訊檔。');
      if (!videoSourceNode) {
        videoSourceNode = ctx.createMediaElementSource(video);
        videoGain = ctx.createGain();
        videoGain.gain.value = 0.65;
        videoSourceNode.connect(videoGain).connect(ctx.destination);
      }
      const audioOut = ctx.createMediaStreamDestination();
      videoSourceNode.connect(audioOut);
      const recorder = new MediaRecorder(audioOut.stream);
      const chunks = [];
      recorder.ondataavailable = (event) => { if (event.data.size) chunks.push(event.data); };
      recorder.onerror = () => reject(new Error('影片音訊擷取失敗。'));
      recorder.onstop = async () => {
        try { resolve(await ctx.decodeAudioData(await new Blob(chunks).arrayBuffer())); }
        catch { reject(new Error('無法讀取影片音軌，請改用 MP3、WAV 或 M4A。')); }
        finally { audioOut.disconnect(); capturePromise = null; }
      };
      const finish = () => { if (recorder.state !== 'inactive') recorder.stop(); video.pause(); };
      video.addEventListener('ended', finish, { once: true });
      recordStop = finish;
      video.currentTime = 0;
      await ctx.resume();
      recorder.start(250);
      await video.play();
    } catch (error) { capturePromise = null; reject(error); }
  });
  return capturePromise;
}

async function handleFile(file) {
  stopMix();
  sourceFile = file;
  audioBuffer = null;
  stems = {};
  controls = {};
  $('mixerContent').hidden = true;
  $('emptyMixer').hidden = false;
  $('stemList').replaceChildren();
  $('fileName').textContent = file.name;
  $('fileMeta').textContent = `${(file.size / 1024 / 1024).toFixed(1)} MB · 讀取中`;
  $('fileCard').hidden = false;
  $('dropZone').hidden = true;
  $('processBtn').disabled = true;
  $('processing').hidden = true;
  if (sourceVideoUrl) URL.revokeObjectURL(sourceVideoUrl);
  sourceVideoUrl = null;
  video.hidden = true;
  $('downloadMv').disabled = true;
  $('mixHint').textContent = '等你放入一首歌';
  try {
    const ctx = initAudio();
    if (file.type.startsWith('video/') || /\.(mp4|webm|mov)$/i.test(file.name)) {
      sourceVideoUrl = objectUrl(file);
      audioBuffer = await loadVideoAudio(file);
    } else {
      audioBuffer = await ctx.decodeAudioData(await file.arrayBuffer());
    }
    $('fileMeta').textContent = `${timeText(audioBuffer.duration)} · ${audioBuffer.numberOfChannels} 聲道`;
    $('processBtn').disabled = false;
    $('mixHint').textContent = '準備好進行分離';
    setNotice('音訊已就緒。按下「開始分離音軌」，首次使用會下載模型。');
  } catch (error) {
    setNotice(error.message || '無法讀取此檔案，請選擇常見音訊或影片格式。', 'error');
    $('fileMeta').textContent = '格式不支援';
  }
}

input.addEventListener('change', (event) => { const file = event.target.files?.[0]; if (file) handleFile(file); });
$('removeFile').addEventListener('click', () => {
  stopMix(); sourceFile = null; audioBuffer = null; stems = {}; controls = {};
  $('fileCard').hidden = true; $('dropZone').hidden = false; $('processing').hidden = true;
  $('mixerContent').hidden = true; $('emptyMixer').hidden = false; $('stemList').replaceChildren(); $('downloadKey').disabled = true; $('downloadMix').disabled = true;
  video.pause(); video.removeAttribute('src'); video.hidden = true; $('downloadMv').disabled = true; input.value = '';
  setNotice('先選擇音訊或影片，再按「開始分離音軌」。');
});

const dropZone = $('dropZone');
for (const eventName of ['dragenter', 'dragover']) dropZone.addEventListener(eventName, (event) => { event.preventDefault(); dropZone.classList.add('dragover'); });
for (const eventName of ['dragleave', 'drop']) dropZone.addEventListener(eventName, (event) => { event.preventDefault(); dropZone.classList.remove('dragover'); });
dropZone.addEventListener('drop', (event) => { const file = event.dataTransfer.files?.[0]; if (file) handleFile(file); });

function progress(percent, line, foot = '') {
  $('processProgress').style.width = `${percent}%`;
  $('progressText').textContent = `${Math.round(percent)}%`;
  if (line) $('statusText').textContent = line;
  if (foot) $('segmentText').textContent = foot;
}

$('processBtn').addEventListener('click', async () => {
  if (!audioBuffer) return;
  $('processBtn').disabled = true;
  $('processing').hidden = false;
  $('modelBadge').innerHTML = '<i></i> 載入中';
  $('modelStatus').textContent = '準備瀏覽器推論環境…';
  $('modelProgress').style.width = '0%';
  setNotice('正在你的裝置上分離音軌。請保持此分頁開啟。', 'busy');
  try {
    await initAudio().resume();
    if (!processor) {
      ort.env.wasm.numThreads = 1;
      let webgpu = false;
      if (navigator.gpu) { try { webgpu = Boolean(await navigator.gpu.requestAdapter()); } catch {} }
      $('backendInfo').textContent = webgpu ? 'WebGPU 可用 · WASM 備援' : 'WASM · 單執行緒相容模式';
      processor = new DemucsProcessor({ ort,
        onDownloadProgress: (loaded, total) => {
          const percent = total ? 100 * loaded / total : 0;
          $('modelProgress').style.width = `${percent}%`;
          $('modelStatus').textContent = `下載模型中 ${(loaded / 1048576).toFixed(0)} / ${(total / 1048576).toFixed(0)} MB`;
          progress(Math.min(12, percent * 0.12), '下載 AI 模型', `${(loaded / 1048576).toFixed(0)} / ${(total / 1048576).toFixed(0)} MB`);
        },
        onLog: (phase, message) => { if (phase === 'model') $('modelStatus').textContent = message === 'Model loaded successfully' ? '模型已就緒，可在此裝置重複使用。' : '正在載入模型…'; },
        onProgress: ({ progress: pct, currentSegment, totalSegments }) => {
          const elapsed = (Date.now() - processStarted) / 1000;
          const remaining = currentSegment ? elapsed / currentSegment * (totalSegments - currentSegment) : 0;
          progress(15 + pct * 85, '分離音軌', `片段 ${currentSegment} / ${totalSegments}`);
          $('etaText').textContent = remaining ? `預估剩餘 ${timeText(remaining)}` : '估計時間 —';
        }
      });
      $('modelStatus').textContent = '從 Hugging Face 載入 HTDemucs 模型（約 172 MB）…';
      await processor.loadModel(DEFAULT_MODEL_URL);
      $('modelBadge').innerHTML = '<i></i> 已就緒';
    }
    const processStarted = Date.now();
    const ratio = SAMPLE_RATE / audioBuffer.sampleRate;
    const sourceL = audioBuffer.getChannelData(0);
    const sourceR = audioBuffer.numberOfChannels > 1 ? audioBuffer.getChannelData(1) : sourceL;
    let left = sourceL; let right = sourceR;
    if (audioBuffer.sampleRate !== SAMPLE_RATE) {
      const length = Math.floor(sourceL.length * ratio);
      left = resample(sourceL, length); right = resample(sourceR, length);
    }
    stems = await processor.separate(left, right);
    controls = Object.fromEntries(Object.keys(stems).map((name) => [name, { gain: 1, mute: false, solo: false }]));
    keyShift = 0; $('keyValue').innerHTML = '0 <small>半音</small>'; $('keyNote').textContent = '原調';
    renderStems();
    $('emptyMixer').hidden = true; $('mixerContent').hidden = false;
    $('durationLabel').textContent = timeText(duration()); $('totalTime').textContent = timeText(duration());
    $('processProgress').style.width = '100%'; $('progressText').textContent = '100%';
    $('statusText').textContent = '分離完成'; $('segmentText').textContent = '四條音軌已準備就緒'; $('etaText').textContent = '完成';
    $('modelBadge').innerHTML = '<i></i> 已就緒'; $('modelStatus').textContent = '模型已就緒，可在此裝置重複使用。';
    $('mixHint').textContent = '4 條音軌已分離';
    $('downloadMix').disabled = false;
    $('downloadKey').disabled = false;
    setNotice(`分離完成。可試聽、調整音量、升降 Key，或下載各音軌。耗時 ${timeText((Date.now() - processStarted) / 1000)}。`, 'success');
  } catch (error) {
    console.error(error);
    $('modelBadge').innerHTML = '<i></i> 發生問題';
    setNotice(`分離失敗：${error.message || error}。請重新載入頁面或改用 WASM 相容瀏覽器。`, 'error');
  } finally { $('processBtn').disabled = !audioBuffer; }
});

function resample(data, length) {
  const out = new Float32Array(length);
  const step = data.length / length;
  for (let i = 0; i < length; i++) { const pos = i * step; const a = Math.floor(pos); const b = Math.min(a + 1, data.length - 1); out[i] = data[a] * (1 - (pos - a)) + data[b] * (pos - a); }
  return out;
}

function renderStems() {
  const list = $('stemList'); list.replaceChildren();
  for (const [name, track] of Object.entries(stems)) {
    const row = document.createElement('div'); row.className = `stem-row ${colors[name]}`;
    row.innerHTML = `<div class="stem-identity"><span class="stem-dot"></span><div><strong>${names[name]}</strong><small>${name.toUpperCase()} STEM</small></div></div><button class="solo-button" type="button" aria-label="獨奏${names[name]}" title="獨奏">S</button><button class="mute-button" type="button" aria-label="靜音${names[name]}" title="靜音">M</button><input class="stem-volume" type="range" min="0" max="1.5" value="1" step="0.01" aria-label="${names[name]}音量" /><span class="volume-label">100%</span><button class="stem-download" type="button" aria-label="下載${names[name]}">↓</button>`;
    const volume = row.querySelector('.stem-volume');
    volume.addEventListener('input', () => { controls[name].gain = Number(volume.value); row.querySelector('.volume-label').textContent = `${Math.round(volume.value * 100)}%`; updateActiveGains(); });
    row.querySelector('.solo-button').addEventListener('click', (event) => { controls[name].solo = !controls[name].solo; event.currentTarget.classList.toggle('active', controls[name].solo); updateActiveGains(); });
    row.querySelector('.mute-button').addEventListener('click', (event) => { controls[name].mute = !controls[name].mute; event.currentTarget.classList.toggle('active', controls[name].mute); updateActiveGains(); });
    row.querySelector('.stem-download').addEventListener('click', () => downloadBlob(wavBlob(track.left, track.right), `${fileStem()}-${name}.wav`));
    list.appendChild(row);
  }
}

function activeGain(name) {
  const anySolo = Object.values(controls).some((v) => v.solo);
  const c = controls[name]; return c.mute || (anySolo && !c.solo) ? 0 : c.gain;
}
function updateActiveGains() { for (const item of playingSources) item.gain.gain.setTargetAtTime(activeGain(item.name), audioContext.currentTime, 0.025); }

function playMix(from = playOffset) {
  stopMix(false);
  if (from >= duration()) from = 0;
  const ctx = initAudio(); const now = ctx.currentTime;
  for (const [name, track] of Object.entries(stems)) {
    const buffer = ctx.createBuffer(2, track.left.length, SAMPLE_RATE);
    buffer.copyToChannel(track.left, 0); buffer.copyToChannel(track.right, 1);
    const source = ctx.createBufferSource(); source.buffer = buffer;
    source.playbackRate.value = semitoneRate();
    const gain = ctx.createGain(); gain.gain.value = activeGain(name);
    source.connect(gain).connect(ctx.destination);
    source.onended = () => { if (source === playingSources.at(-1)?.source) { isPlaying = false; $('playMix').textContent = '▶'; playOffset = 0; } };
    source.start(now, from); playingSources.push({ name, source, gain });
  }
  playStartedAt = now; playOffset = from; isPlaying = true; $('playMix').textContent = 'Ⅱ';
}

function stopMix(reset = true) {
  for (const item of playingSources) { try { item.source.stop(); } catch {} }
  playingSources = []; isPlaying = false;
  if (reset) playOffset = 0;
  $('playMix').textContent = '▶';
}
$('playMix').addEventListener('click', async () => {
  if (!Object.keys(stems).length) return;
  await initAudio().resume();
  if (isPlaying) { playOffset = Math.min(duration(), playOffset + audioContext.currentTime - playStartedAt); stopMix(false); }
  else playMix(playOffset);
});
$('seekBar').addEventListener('input', () => { const next = duration() * Number($('seekBar').value) / 1000; if (isPlaying) playMix(next); else playOffset = next; updateTransport(); });
setInterval(() => { if (isPlaying) { playOffset = Math.min(duration(), playOffset + audioContext.currentTime - playStartedAt); playStartedAt = audioContext.currentTime; updateTransport(); } }, 200);
function updateTransport() { $('currentTime').textContent = timeText(playOffset); $('seekBar').value = duration() ? Math.round(playOffset / duration() * 1000) : 0; }

$('resetMix').addEventListener('click', () => {
  for (const name of Object.keys(controls)) controls[name] = { gain: 1, mute: false, solo: false };
  renderStems(); updateActiveGains();
});

$('keyDown').addEventListener('click', () => setKey(keyShift - 1));
$('keyUp').addEventListener('click', () => setKey(keyShift + 1));
function setKey(value) {
  keyShift = Math.max(-6, Math.min(6, value));
  const label = keyShift > 0 ? `+${keyShift}` : String(keyShift);
  $('keyValue').innerHTML = `${label} <small>半音</small>`;
  $('keyNote').textContent = keyShift === 0 ? '原調' : `${keyShift > 0 ? '升高' : '降低'} ${Math.abs(keyShift)} 個半音`;
  for (const item of playingSources) item.source.playbackRate.setTargetAtTime(semitoneRate(), audioContext.currentTime, 0.025);
}
function semitoneRate() { return Math.pow(2, keyShift / 12); }

$('downloadMix').addEventListener('click', () => exportMix('stemroom-accompaniment.wav'));
$('downloadKey').addEventListener('click', () => exportMix(`${fileStem()}-${keyShift >= 0 ? '+' : ''}${keyShift}st.wav`));
$('downloadMix').disabled = true;
function exportMix(filename) {
  if (!Object.keys(stems).length) return;
  const mix = buildMix();
  const rate = semitoneRate();
  const outputLength = Math.max(1, Math.floor(mix.left.length / rate));
  const left = resample(mix.left, outputLength); const right = resample(mix.right, outputLength);
  downloadBlob(wavBlob(left, right), filename);
}
function buildMix() {
  const length = Object.values(stems)[0].left.length;
  const left = new Float32Array(length); const right = new Float32Array(length);
  for (const [name, track] of Object.entries(stems)) {
    const gain = activeGain(name); if (!gain) continue;
    for (let i = 0; i < length; i++) { left[i] += track.left[i] * gain; right[i] += track.right[i] * gain; }
  }
  let peak = 0;
  for (let i = 0; i < length; i++) peak = Math.max(peak, Math.abs(left[i]), Math.abs(right[i]));
  if (peak > 0.99) { const trim = 0.99 / peak; for (let i = 0; i < length; i++) { left[i] *= trim; right[i] *= trim; } }
  return { left, right };
}

function wavBlob(left, right) {
  const channels = [left, right]; const frames = left.length; const bytes = new ArrayBuffer(44 + frames * 4); const view = new DataView(bytes);
  const text = (at, value) => [...value].forEach((char, index) => view.setUint8(at + index, char.charCodeAt(0)));
  text(0, 'RIFF'); view.setUint32(4, bytes.byteLength - 8, true); text(8, 'WAVE'); text(12, 'fmt ');
  view.setUint32(16, 16, true); view.setUint16(20, 1, true); view.setUint16(22, 2, true); view.setUint32(24, SAMPLE_RATE, true); view.setUint32(28, SAMPLE_RATE * 4, true); view.setUint16(32, 4, true); view.setUint16(34, 16, true); text(36, 'data'); view.setUint32(40, frames * 4, true);
  let offset = 44;
  for (let i = 0; i < frames; i++) for (const channel of channels) { const value = Math.max(-1, Math.min(1, channel[i])); view.setInt16(offset, value < 0 ? value * 32768 : value * 32767, true); offset += 2; }
  return new Blob([bytes], { type: 'audio/wav' });
}
function downloadBlob(blob, filename) { const url = objectUrl(blob); const link = document.createElement('a'); link.href = url; link.download = filename; link.click(); setTimeout(() => URL.revokeObjectURL(url), 60_000); }
function fileStem() { return (sourceFile?.name || 'stemroom').replace(/\.[^.]+$/, '').replace(/[\\/:*?"<>|]/g, '_'); }

$('downloadMv').addEventListener('click', async () => {
  if (!video.src || !Object.keys(stems).length) return;
  if (!window.MediaRecorder || !video.captureStream) { setNotice('此瀏覽器不支援 MV 錄製，請使用新版 Chrome 或 Edge。', 'error'); return; }
  const mix = buildMix(); const rate = semitoneRate();
  const left = resample(mix.left, Math.floor(mix.left.length / rate)); const right = resample(mix.right, Math.floor(mix.right.length / rate));
  const ctx = initAudio(); await ctx.resume();
  const buffer = ctx.createBuffer(2, left.length, SAMPLE_RATE); buffer.copyToChannel(left, 0); buffer.copyToChannel(right, 1);
  const videoStream = video.captureStream(); const output = ctx.createMediaStreamDestination();
  const source = ctx.createBufferSource(); source.buffer = buffer; source.connect(output);
  if (videoSourceNode && videoGain) videoGain.gain.value = 0;
  const stream = new MediaStream([...videoStream.getVideoTracks(), ...output.stream.getAudioTracks()]);
  const mimeType = MediaRecorder.isTypeSupported('video/webm;codecs=vp9,opus') ? 'video/webm;codecs=vp9,opus' : 'video/webm';
  const recorder = new MediaRecorder(stream, { mimeType }); const chunks = [];
  recorder.ondataavailable = (event) => { if (event.data.size) chunks.push(event.data); };
  recorder.onstop = () => {
    source.disconnect(); output.disconnect(); videoStream.getTracks().forEach((track) => track.stop());
    if (videoGain) videoGain.gain.value = 0.65;
    downloadBlob(new Blob(chunks, { type: 'video/webm' }), `${fileStem()}-伴奏MV.webm`);
    $('downloadMv').disabled = false; $('downloadMv').innerHTML = '輸出伴奏 MV <span>↗</span>';
    setNotice('伴奏 MV 已輸出，檔案格式為 WEBM。', 'success');
  };
  $('downloadMv').disabled = true; $('downloadMv').innerHTML = '正在錄製…';
  setNotice('正在即時合成影片。請保持頁面開啟直到匯出完成。', 'busy');
  video.currentTime = 0; video.muted = true; recorder.start(500);
  await video.play(); source.start();
  video.addEventListener('ended', () => { if (recorder.state !== 'inactive') recorder.stop(); video.muted = false; }, { once: true });
});

if (navigator.gpu) $('backendInfo').textContent = 'WebGPU 可用 · WASM 備援';
else $('backendInfo').textContent = 'WASM · 單執行緒相容模式';
